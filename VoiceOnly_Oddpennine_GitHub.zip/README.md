# 🎤 Voice Keeper | Oddpennine

**노래에서 원래 녹음된 목소리(vocals)와 반주(instrumental)를 분리**하는 개인용 도구입니다. AI 보컬 생성, 음성 복제, 가수 음색 학습 기능은 없습니다.

> GitHub Pages는 정적 웹 호스팅이어서 Demucs/Python 음원 분리를 웹페이지 안에서 실행할 수 없습니다. `index.html`은 사용 안내 페이지이고, 실제 분리는 PC의 `app.py`나 Google Colab 노트북에서 실행합니다.

## 컴퓨터에서 사용하기

1. Python 3.11 또는 3.12와 [FFmpeg](https://ffmpeg.org/download.html) 설치. Windows의 경우 설치 때 `Add Python to PATH` 선택. FFmpeg와 ffprobe를 PATH에서 사용할 수 있어야 합니다.
2. 이 저장소의 **Code → Download ZIP** 또는 `git clone`으로 파일 받기.
3. Windows: `start_windows.bat` 실행 / macOS·Linux: `bash start_mac_linux.sh` 실행.
4. 브라우저에서 `http://127.0.0.1:7860` 열기. 음원 업로드 → **AI 보컬 분리 (추천)** → 분리 버튼 클릭.
5. `vocals.mp3`와 `no_vocals.mp3`를 따로 다운로드합니다.

첫 실행에는 Demucs 모델 등 의존성을 다운로드합니다. CPU만으로도 가능하나 오래 걸릴 수 있습니다. **자동으로 인터넷 서버에 음원을 올리지 않는 로컬 처리 방식**입니다(모델 다운로드에 인터넷 필요).

### Python 수동 실행

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

## 스마트폰에서 Colab으로 분리하기

저장소에 들어 있는 [`VoiceKeeper_Colab.ipynb`](./VoiceKeeper_Colab.ipynb) 파일을 Google Colab으로 열고, 위에서부터 순서대로 네 개의 셀을 실행합니다. 음원은 **Google Colab 임시 환경에 업로드**되며, 분리 결과는 ZIP으로 다운로드됩니다.

이 저장소에 파일을 업로드하면 아래 링크로 바로 열 수도 있습니다.

[▶ Colab에서 Voice Keeper 열기](https://colab.research.google.com/github/oddpennine/voiceonly/blob/main/VoiceKeeper_Colab.ipynb)

## 두 가지 분리 모드

| 모드 | 동작 | 한계 |
| --- | --- | --- |
| AI 보컬 분리 (추천) | Demucs `htdemucs` 또는 `htdemucs_ft`로 원곡 전체의 보컬과 반주를 분리 | 악기 잔향이 남을 수 있음 / 모델 다운로드 필요 |
| 간이 분리 | 반복 반주 억제를 이용해 처음 최대 60초를 빠르게 미리듣기 | 실제 스템 분리가 아니어서 반주가 많이 섞일 수 있음 |

## GitHub Pages를 켜려면 (선택)

Repository **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)`**. 웹사이트에는 설치와 실행 안내만 표시됩니다. 실제 음원 처리는 `app.py` 또는 Colab에서 이루어집니다.

## 보안 / 저작권

- 원곡 MP3와 분리된 보컬 파일은 이 저장소에 넣지 않습니다(`.gitignore`에 제외 규칙 포함).
- 공개 저장소에 저작권이 있는 음악이나 녹음을 무단 업로드하지 마세요.
- 원곡에서 추출한 보컬을 공개·배포하거나 리믹스를 발표할 경우 관련 권리자 허락이 필요할 수 있습니다.
- 다른 사용자에게 공개 서버로 호스팅하려면 업로드 용량, 접근 제어, 파일 삭제 및 보안 설계가 별도로 필요합니다.

## 트러블슈팅

- `ffmpeg`, `ffprobe`를 찾지 못하면 FFmpeg 설치 후 터미널을 다시 열어 보세요.
- 모델 다운로드 오류는 네트워크 상태, 저장 공간 등을 확인하세요.
- 보컬에 반주가 남으면 `htdemucs_ft`를 시도할 수 있지만 분리 품질은 원곡에 따라 다릅니다.
