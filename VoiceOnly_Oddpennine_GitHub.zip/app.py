"""Voice Keeper: original vocal isolation web UI.
Runs locally on the user's computer. AI mode requires Demucs htdemucs weights.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import uuid
from pathlib import Path

import gradio as gr

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "outputs"
OUTPUT.mkdir(exist_ok=True)


def _clean_name(name: str) -> str:
    clean = re.sub(r"[^\w\-.가-힣]+", "_", name, flags=re.UNICODE)
    return clean[:70] or "song"


def _audio_to_mp3(wave, sr: int, destination: Path):
    import soundfile as sf
    import shutil
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        destination = destination.with_suffix('.wav')
        sf.write(str(destination), wave, sr, subtype="PCM_16")
        return destination
    wav = destination.with_suffix('.wav')
    sf.write(str(wav), wave, sr, subtype="PCM_16")
    try:
        subprocess.run([ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
                        '-i', str(wav), '-codec:a', 'libmp3lame', '-b:a', '192k',
                        str(destination)], check=True, capture_output=True)
    finally:
        wav.unlink(missing_ok=True)
    return destination


def _quick_filter(src: Path, folder: Path):
    """Repetition suppression: rough, not true vocal isolation."""
    import numpy as np
    import librosa
    from scipy.signal import butter, sosfiltfilt

    sample_rate = 22050
    duration = min(60.0, float(librosa.get_duration(path=str(src))))
    y, sample_rate = librosa.load(str(src), sr=sample_rate, mono=True, duration=duration)
    if len(y) < sample_rate * 2:
        raise ValueError("음원이 너무 짧아. 2초 이상 되는 파일을 넣어줘.")
    hop = 512
    S = librosa.stft(y, n_fft=2048, hop_length=hop)
    mag = abs(S)
    filt = librosa.decompose.nn_filter(
        mag, aggregate=np.median, metric="cosine",
        width=int(librosa.time_to_frames(2, sr=sample_rate, hop_length=hop)), k=12)
    filt = np.minimum(mag, filt)
    mask = librosa.util.softmask(mag - filt, 5 * filt, power=2)
    vocals = librosa.istft(mask * S, hop_length=hop, length=len(y))
    highpass = butter(3, 100, fs=sample_rate, btype="highpass", output="sos")
    vocals = sosfiltfilt(highpass, vocals)
    instrumental = np.clip(y - vocals, -1, 1)
    # normalize the preview moderately without hard clipping
    gain = min(2.8, 0.13 / max(float(np.sqrt(np.mean(vocals**2))), 0.01))
    vocals = np.clip(vocals * gain, -.98, .98)
    vocal_path = _audio_to_mp3(vocals, sample_rate, folder / "rough_vocals.mp3")
    backing_path = _audio_to_mp3(instrumental, sample_rate, folder / "rough_backing.mp3")
    return vocal_path, backing_path


def _ai_separate(src: Path, folder: Path, model: str):
    import shutil
    if not shutil.which('ffprobe') or not shutil.which('ffmpeg'):
        raise RuntimeError("AI 분리에는 FFmpeg와 FFprobe가 필요해. README의 설치 안내를 참고해줘.")
    command = [sys.executable, "-m", "demucs", "--two-stems", "vocals",
               "-n", model, "--mp3", "--mp3-bitrate", "192", "--out", str(folder), str(src)]
    try:
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
    except FileNotFoundError as ex:
        raise RuntimeError("Demucs를 실행할 수 없어. 설치 상태를 확인해줘.") from ex
    if proc.returncode:
        logs = (proc.stderr or proc.stdout or "")[-2400:]
        raise RuntimeError("Demucs 분리 실패. 모델 다운로드나 FFmpeg 설치를 확인해줘.\n" + logs)
    tracks = folder / model / src.stem
    v = tracks / "vocals.mp3"
    i = tracks / "no_vocals.mp3"
    if not v.exists() or not i.exists():
        raise RuntimeError("분리 작업은 끝났지만 파일을 찾지 못했어. 결과 폴더를 확인해줘.")
    return v, i


def separate(file_path: str | None, mode: str, model: str):
    if not file_path:
        raise gr.Error("MP3나 WAV 파일을 먼저 선택해 줘.")
    source = Path(file_path)
    if not source.is_file():
        raise gr.Error("업로드된 파일을 읽지 못했어.")
    if source.suffix.lower() not in {'.mp3', '.wav', '.flac', '.ogg', '.m4a'}:
        raise gr.Error("MP3, WAV, FLAC, OGG, M4A 형식을 사용해 줘.")
    output_dir = OUTPUT / f"{_clean_name(source.stem)}_{uuid.uuid4().hex[:8]}"
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        if mode.startswith('AI'):
            vocal, back = _ai_separate(source, output_dir, model)
            status = ("✅ AI 보컬 분리 완료. 보컬과 반주를 각각 내려받을 수 있어. "
                      "원곡 믹스 특성에 따라 악기 잔향이 약간 남을 수 있어.")
        else:
            vocal, back = _quick_filter(source, output_dir)
            status = ("✅ 간이 미리듣기 완료 (곡의 처음 최대 60초). "
                      "이는 반복 반주 억제 방식으로, 진짜 AI 보컬 분리보다 악기 소리가 많이 남을 수 있어.")
    except Exception as ex:
        raise gr.Error(str(ex)) from ex
    return status, str(vocal), str(vocal), str(back)

with gr.Blocks(title="Voice Keeper | 목소리만 남기기") as demo:
    gr.Markdown("""# 🎤 Voice Keeper
**노래에서 가수의 원래 목소리를 남기고 반주를 분리하는 로컬 앱**

파일은 내 컴퓨터에서 처리해. AI 모드는 Demucs 모델을 사용하며 **처음 실행 시 모델을 인터넷에서 내려받아야** 해.
분리된 보컬에 악기 잔향이 일부 섞일 수 있고, 이 도구는 새로운 목소리를 생성하거나 가수의 음색을 학습하지 않아.
""")
    track = gr.File(label="분리할 음원 업로드", type="filepath", file_types=[".mp3", ".wav", ".m4a", ".flac", ".ogg"])
    with gr.Row():
        mode = gr.Radio(["AI 보컬 분리 (추천)", "간이 분리 (설치 모델 없이, 60초 미리듣기)"],
                        value="AI 보컬 분리 (추천)", label="분리 방식")
        model = gr.Dropdown(["htdemucs", "htdemucs_ft"], value="htdemucs",
                            label="AI 모델", info="htdemucs_ft는 더 느리지만 경우에 따라 분리 품질이 나아질 수 있어")
    run = gr.Button("🎵 목소리만 남기기", variant="primary")
    result = gr.Markdown()
    sample = gr.Audio(label="분리된 보컬 미리듣기", type="filepath")
    with gr.Row():
        vfile = gr.File(label="보컬만 저장")
        bfile = gr.File(label="반주만 저장")
    run.click(fn=separate, inputs=[track, mode, model], outputs=[result, sample, vfile, bfile])
    gr.Markdown("""---
**사용 팁:** 임재범 〈Dream of Vision〉처럼 반주가 꽉 찬 곡은 AI 분리를 선택하는 게 좋아. 
로파이/트랜스 리믹스에는 다운로드한 **보컬 파일**을 불러오고 새 반주를 따로 만드는 편이 원곡 반주를 겹치는 것보다 훨씬 깔끔해.
공개·배포 전에는 원곡과 보컬 녹음의 권리를 확인해 줘.
""")

if __name__ == '__main__':
    demo.launch(inbrowser=True, server_name="127.0.0.1", server_port=7860, allowed_paths=[str(OUTPUT)])
